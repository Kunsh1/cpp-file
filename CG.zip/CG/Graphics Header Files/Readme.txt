Tools->Compiler options->32bit release

-static-libgcc -lbgi -lgdi32 -lcomdlg32 -luuid -loleaut32 -lole32

Dev-C++ header files directory:
C:\Program Files (x86)\Dev-Cpp\MinGW64\include

Dev-C++ lib directory:
C:\Program Files (x86)\Dev-Cpp\MinGW64\lib