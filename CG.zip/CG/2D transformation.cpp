#include <iostream>
#include <graphics.h>
#include <cmath>

#define PI 3.14159265
#define NUM_VERTICES 4

using namespace std;

void matrixMultiplication(float X[][3], float T[][3], float result[][3]) {
    for (int i = 0; i < NUM_VERTICES; i++) {
        for (int j = 0; j < 3; j++) {
            result[i][j] = 0;
            for (int k = 0; k < 3; k++) {
                result[i][j] += X[i][k] * T[k][j];
            }
        }
    }
}

void drawPolygon(float X[][3]) {
    for (int i = 0; i < NUM_VERTICES; i++) {
        line(X[i][0], X[i][1], X[(i + 1) % NUM_VERTICES][0], X[(i + 1) % NUM_VERTICES][1]);
    }
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, (char*)"");

    float originalVertices[NUM_VERTICES][3] = {
        {100, 100, 1},
        {200, 100, 1},
        {200, 200, 1},
        {100, 200, 1}
    };

    float transformedVertices[NUM_VERTICES][3];

    drawPolygon(originalVertices);
    getch();

    float translationMatrix[3][3] = {
        {1, 0, 0},
        {0, 1, 0},
        {50, 50, 1}
    };

    // Apply translation
    matrixMultiplication(originalVertices, translationMatrix, transformedVertices);
    setcolor(YELLOW);
    drawPolygon(transformedVertices);
    getch();

    float scalingMatrix[3][3] = {
        {2, 0, 0},
        {0, 2, 0},
        {0, 0, 1}
    };

    // Apply scaling
    matrixMultiplication(originalVertices, scalingMatrix, transformedVertices);
    setcolor(BLUE);
    drawPolygon(transformedVertices);
    getch();

    // Rotation matrix
    float angle = 15;
    float radian = angle * PI / 180.0;
    float rotationMatrix[3][3] = {
        {cos(radian), -sin(radian), 0},
        {sin(radian), cos(radian), 0},
        {0, 0, 1}
    };

    // Apply rotation
    matrixMultiplication(originalVertices, rotationMatrix, transformedVertices);
    setcolor(RED);
    drawPolygon(transformedVertices);
    getch();

    closegraph();
    return 0;
}
