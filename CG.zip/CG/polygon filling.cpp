#include <graphics.h>
#include <conio.h>
#include <iostream>
#include <algorithm>
using namespace std;

const int MAX_POINTS = 20;

void scanlineFill(int x[], int y[], int n) {
    int i, j, k;
    int ymin = y[0], ymax = y[0];

    for (i = 1; i < n; i++) {
        if (y[i] < ymin) ymin = y[i];
        if (y[i] > ymax) ymax = y[i];
    }

    for (int scanline = ymin; scanline <= ymax; scanline++) {
        int intersections[MAX_POINTS];
        int count = 0;

        for (i = 0; i < n; i++) {
            int x1 = x[i];
            int y1 = y[i];
            int x2 = x[(i + 1) % n];
            int y2 = y[(i + 1) % n];

            if (y1 != y2) {
                if ((scanline >= y1 && scanline < y2) || (scanline >= y2 && scanline < y1)) {
                    int intersectX = x1 + (scanline - y1) * (x2 - x1) / (y2 - y1);
                    intersections[count++] = intersectX;
                }
            }
        }

        for (int i = 0; i < count - 1; i++) {
            for (int j = 0; j < count - i - 1; j++) {
                if (intersections[j] > intersections[j + 1]) {
                    swap(intersections[j], intersections[j + 1]);
                }
            }
        }

        for (i = 0; i < count; i += 2) {
            line(intersections[i], scanline, intersections[i + 1], scanline);
        }
    }
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, (char*)"");

    int x[] = {150, 175, 200, 225, 250};
    int y[] = {150, 100, 125, 100, 150};
    int n = 5;

    for (int i = 0; i < n; i++) {
        line(x[i], y[i], x[(i + 1) % n], y[(i + 1) % n]);
    }

    getch();

    scanlineFill(x, y, n);

    getch();
    closegraph();
    return 0;
}
