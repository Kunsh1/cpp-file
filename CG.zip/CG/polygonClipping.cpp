#include <graphics.h>
#include <conio.h>

const int MAX_POINTS = 20;

void findIntersection(int x1, int y1, int x2, int y2, int xmin, int ymin, int xmax, int ymax, int* x, int* y, int edge) {
    if (edge == 0) {
        *x = xmin;
        *y = y1 + (y2 - y1) * (xmin - x1) / (x2 - x1);
    } else if (edge == 1) {
        *x = xmax;
        *y = y1 + (y2 - y1) * (xmax - x1) / (x2 - x1);
    } else if (edge == 2) {
        *y = ymin;
        *x = x1 + (x2 - x1) * (ymin - y1) / (y2 - y1);
    } else if (edge == 3) {
        *y = ymax;
        *x = x1 + (x2 - x1) * (ymax - y1) / (y2 - y1);
    }
}

bool inside(int x, int y, int xmin, int ymin, int xmax, int ymax, int edge) {
    if (edge == 0) return x >= xmin; 
    if (edge == 1) return x <= xmax; 
    if (edge == 2) return y >= ymin; 
    return y <= ymax;                
}

void sutherlandHodgmanClip(int polygon[], int n, int xmin, int ymin, int xmax, int ymax, int* clippedPolygon, int* clippedSize) {
    int tempPolygon[MAX_POINTS * 2];
    int tempSize;

    for (int edge = 0; edge < 4; ++edge) {
        tempSize = 0;

        for (int i = 0; i < n; ++i) {
            int x1 = polygon[2 * i];
            int y1 = polygon[2 * i + 1];
            int x2 = polygon[2 * ((i + 1) % n)];
            int y2 = polygon[2 * ((i + 1) % n) + 1];

            bool isInside1 = inside(x1, y1, xmin, ymin, xmax, ymax, edge);
            bool isInside2 = inside(x2, y2, xmin, ymin, xmax, ymax, edge);

            if (isInside1 && isInside2) {
                tempPolygon[2 * tempSize] = x2;
                tempPolygon[2 * tempSize + 1] = y2;
                ++tempSize;
            } else if (isInside1 && !isInside2) { 
                int ix, iy;
                findIntersection(x1, y1, x2, y2, xmin, ymin, xmax, ymax, &ix, &iy, edge);
                tempPolygon[2 * tempSize] = ix;
                tempPolygon[2 * tempSize + 1] = iy;
                ++tempSize;
            } else if (!isInside1 && isInside2) {
                int ix, iy;
                findIntersection(x1, y1, x2, y2, xmin, ymin, xmax, ymax, &ix, &iy, edge);
                tempPolygon[2 * tempSize] = ix;
                tempPolygon[2 * tempSize + 1] = iy;
                ++tempSize;
                tempPolygon[2 * tempSize] = x2;
                tempPolygon[2 * tempSize + 1] = y2;
                ++tempSize;
            }
        }

        for (int i = 0; i < tempSize * 2; ++i) {
            polygon[i] = tempPolygon[i];
        }
        n = tempSize;
    }

    *clippedSize = n;
    for (int i = 0; i < n * 2; ++i) {
        clippedPolygon[i] = polygon[i];
    }
}

void drawPolygon(int polygon[], int n) {
    for (int i = 0; i < n; ++i) {
        int x1 = polygon[2 * i];
        int y1 = polygon[2 * i + 1];
        int x2 = polygon[2 * ((i + 1) % n)];
        int y2 = polygon[2 * ((i + 1) % n) + 1];
        line(x1, y1, x2, y2);
    }
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, (char*)"");

    int xmin = 100, ymin = 100, xmax = 300, ymax = 300;
    rectangle(xmin, ymin, xmax, ymax);

    int polygon[MAX_POINTS*2] = {
        50, 50,
        350, 150,
        300, 350,
        150, 350 
    };
    int n = 4;

    drawPolygon(polygon, n);
    getch();

    int clippedPolygon[MAX_POINTS * 2];
    int clippedSize;
    sutherlandHodgmanClip(polygon, n, xmin, ymin, xmax, ymax, clippedPolygon, &clippedSize);

    setcolor(RED);
    drawPolygon(clippedPolygon, clippedSize);

    getch();
    closegraph();
    return 0;
}
