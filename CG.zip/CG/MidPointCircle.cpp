#include <iostream>
#include <graphics.h>
using namespace std;

void printCoord(int x, int y){
    cout<<""<<x<<","<<y<<")";
}

void MidpntAlgo(int xk, int yk, int P, int xShift, int yShift){
    if(P<0){
        int xkn = xk + 1, ykn = yk;
        if(xkn < ykn){
            printCoord(xkn, ykn);
            printCoord(ykn, xkn);
            printCoord(xkn, -ykn);
            printCoord(ykn, -xkn);
            printCoord(-xkn, -ykn);
            printCoord(-ykn, -xkn);
            printCoord(-xkn, ykn);
            printCoord(-ykn, xkn);
            line((xk) + xShift, (yk) + yShift, (xkn) + xShift, (ykn) + yShift);
            line((yk) + xShift, (xk) + yShift, (ykn) + xShift, (xkn) + yShift);
            line((xk) + xShift, -(yk) + yShift, (xkn) + xShift, -(ykn) + yShift);
            line((yk) + xShift, -(xk) + yShift, (ykn) + xShift, -(xkn) + yShift);
            line(-(xk) + xShift, (yk) + yShift, -(xkn) + xShift, (ykn) + yShift);
            line(-(yk) + xShift, (xk) + yShift, -(ykn) + xShift, (xkn) + yShift);
            line(-(xk) + xShift, -(yk) + yShift, -(xkn) + xShift, -(ykn) + yShift);
            line(-(yk) + xShift, -(xk) + yShift, -(ykn) + xShift, -(xkn) + yShift);
            MidpntAlgo(xkn, ykn, P + (2 * xkn) + 3, xShift, yShift);
        }
    }
    else if(P >= 0){
        int xkn = xk + 1, ykn = yk - 1;
        if(xkn < ykn){
            printCoord(xkn, ykn);
            printCoord(ykn, xkn);
            printCoord(xkn, -ykn);
            printCoord(ykn, -xkn);
            printCoord(-xkn, -ykn);
            printCoord(-ykn, -xkn);
            printCoord(-xkn, ykn);
            printCoord(-ykn, xkn);
            line((xk) + xShift, (yk) + yShift, (xkn) + xShift, (ykn) + yShift);
            line((yk) + xShift, (xk) + yShift, (ykn) + xShift, (xkn) + yShift);
            line((xk) + xShift, -(yk) + yShift, (xkn) + xShift, -(ykn) + yShift);
            line((yk) + xShift, -(xk) + yShift, (ykn) + xShift, -(xkn) + yShift);
            line(-(xk) + xShift, (yk) + yShift, -(xkn) + xShift, (ykn) + yShift);
            line(-(yk) + xShift, (xk) + yShift, -(ykn) + xShift, (xkn) + yShift);
            line(-(xk) + xShift, -(yk) + yShift, -(xkn) + xShift, -(ykn) + yShift);
            line(-(yk) + xShift, -(xk) + yShift, -(ykn) + xShift, -(xkn) + yShift);
            MidpntAlgo(xkn, ykn, P + (2 * xkn) - (2 * ykn) + 5, xShift, yShift);
        }
    }
}

int main(){
    int r;
    int xShift = 660, yShift = 420;
    cout<<"Enter radius of the circle : ";
    cin>>r;
    int x = 0, y = r, P = (1-r);

    int gd = DETECT, gm;
    // initgraph(&gd, &gm, (char*)"");
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    initwindow(screenWidth, screenHeight, "Full Size BGI Window");

    printCoord(x, y);
    MidpntAlgo(x, y, P, xShift, yShift);

    getch();
    closegraph();

    return 0;
}