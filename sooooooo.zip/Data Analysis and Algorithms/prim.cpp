#include <iostream>
#include <climits>
using namespace std;

#define V 5         // Number of vertices
#define INF 9999    // Represents no edge

void primMST(int cost[V][V]) {
    int parent[V];     // Stores constructed MST
    int key[V];        // Key values used to pick minimum weight edge
    bool mstSet[V];    // To represent vertices included in MST

    // Initialize all keys as INFINITE and mstSet[] as false
    for (int i = 0; i < V; i++) {
        key[i] = INF;
        mstSet[i] = false;
    }

    key[0] = 0;       // Include first vertex in MST
    parent[0] = -1;   // First node is root of MST

    for (int count = 0; count < V - 1; count++) {
        int min = INF, u;

        // Pick the minimum key vertex from the set of vertices not yet included
        for (int v = 0; v < V; v++) {
            if (!mstSet[v] && key[v] < min) {
                min = key[v];
                u = v;
            }
        }

        mstSet[u] = true;  // Include the picked vertex in MST

        // Update key and parent index of the adjacent vertices
        for (int v = 0; v < V; v++) {
            if (cost[u][v] && cost[u][v] < key[v] && !mstSet[v]) {
                parent[v] = u;
                key[v] = cost[u][v];
            }
        }
    }

    // Print the constructed MST
    cout << "Edge \tWeight\n";
    for (int i = 1; i < V; i++)
        cout << parent[i] << " - " << i << "\t" << cost[i][parent[i]] << "\n";
}

int main() {
    // Hardcoded graph (0 = no edge)
    int cost[V][V] = {
        {0, 2, 0, 6, 0},
        {2, 0, 3, 8, 5},
        {0, 3, 0, 0, 7},
        {6, 8, 0, 0, 9},
        {0, 5, 7, 9, 0}
    };

    // Replace 0s with INF except on the diagonal
    for (int i = 0; i < V; i++)
        for (int j = 0; j < V; j++)
            if (cost[i][j] == 0 && i != j)
                cost[i][j] = INF;

    primMST(cost);
    return 0;
}
