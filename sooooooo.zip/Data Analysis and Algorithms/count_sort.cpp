#include <iostream>
using namespace std;

void countSort(int arr[], int n) {
    // Finding max element
    int maxElement = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] > maxElement) {
            maxElement = arr[i];
        }
    }

    // Frequency Array
    int count[maxElement + 1] = {0};
    for (int i = 0; i < n; i++) {
        count[arr[i]]++;
    }

    // Frequency accumulation
    for (int i = 1; i <= maxElement; i++) {
        count[i] += count[i - 1];
    }

    int output[n];

    for (int i = n - 1; i >= 0; i--) {
        output[count[arr[i]] - 1] = arr[i];
        count[arr[i]]--;
    }

    // COPYING TO ORIGINAL ARRAY
    for (int i = 0; i < n; i++) {
        arr[i] = output[i];
    }
}

int main() {
    int arr[] = {4, 2, 2, 8, 3, 3, 1};
    int n = sizeof(arr) / sizeof(arr[0]);

    countSort(arr, n);

    cout << "Sorted array: ";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
} 