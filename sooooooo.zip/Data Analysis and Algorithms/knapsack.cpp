#include <iostream>
using namespace std;

#define MAX_ITEMS 100
#define MAX_WEIGHT 100

int knapsack(int W, int weights[], int values[], int n) {
    int dp[MAX_ITEMS + 1][MAX_WEIGHT + 1];

    // Initialize the DP table
    for (int i = 0; i <= n; i++) {
        for (int w = 0; w <= W; w++) {
            // Base case: no items or zero capacity
            if (i == 0 || w == 0)
                dp[i][w] = 0;
            // If weight of item i-1 is less than or equal to w
            else if (weights[i - 1] <= w)
                dp[i][w] = max(
                    values[i - 1] + dp[i - 1][w - weights[i - 1]],
                    dp[i - 1][w]
                );
            else
                dp[i][w] = dp[i - 1][w];
        }
    }

    return dp[n][W];
}

int main() {
    // Example: 3 items, capacity = 50
    int values[] = {60, 100, 120};
    int weights[] = {10, 20, 30};
    int n = 3;
    int capacity = 50;

    int maxProfit = knapsack(capacity, weights, values, n);

    cout << "Maximum value that can be carried: " << maxProfit << endl;

    return 0;
}
