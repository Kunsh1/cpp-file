#include <iostream>
using namespace std;

int comparisons = 0;

void insertionSort(int arr[], int n){

    for(int i = 1; i < n; i++){
        int key = arr[i];
        int j = i - 1;
        comparisons++;
        while (j >= 0 && arr[j] > key)
        {   
            comparisons ++;
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}


int main(){
    int arr[] = {20, 50, 80, 30, 40};

    int size = sizeof(arr)/sizeof(arr[0]);

    insertionSort(arr, size);

    for (int i = 0; i < size; i++)
    {
        cout << arr[i] << " ";
    }
    
    cout << endl << "COMPARISONS : " << comparisons;
}