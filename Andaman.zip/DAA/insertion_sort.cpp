#include<iostream>
using namespace std;

// Function to perform Insertion Sort on the array
void insertionSort(int* ar, int n) {
    int c = 0; // Counter to track number of comparisons
    // Loop over the array starting from the second element
    for (int j = 1; j < n; j++) { // j was i
        int key = ar[j]; // Store the current element (to be inserted in sorted part)
        int i = j - 1;    // i was j

        // Move elements of ar[0..j-1], that are greater than key,
        // to one position ahead of their current position
        while (i >= 0) {
            c++; // Count this comparison
            if (key < ar[i]) {
                ar[i + 1] = ar[i]; // Shift element right
                i = i - 1;         // Move one step left in sorted part
            }
            else {
                break; // If current element is already in correct place, stop
            }
        }
        // Insert the key in its correct position in the sorted part
        ar[i + 1] = key;
    }
    cout << "number of comparisons : " << c << endl;
}

// Function to print the elements of the array
void printArray(int* ar, int n) {
    for (int i = 0; i < n; i++) {
        cout << ar[i] << " ";
    }
    cout << endl;
}

int main() {
    int n;
    cout << "Enter the number of elements: ";
    cin >> n;

    // Dynamically allocating array of size n
    int* p = new int[n];

    // Taking input from user
    cout << "Enter the elements: " << endl;
    for (int i = 0; i < n; i++) {
        cin >> p[i];
    }

    // Print array before sorting
    printArray(p, n);

    // Sort array using insertion sort
    insertionSort(p, n);

    // Print array after sorting
    printArray(p, n);

    return 0;
}
