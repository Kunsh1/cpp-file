#include<iostream>
using namespace std;

void countSort(int* p, int n){
    int max = p[0];
    for (int i = 1; i < n; i++){
        if (p[i] > max){
            max = p[i];
        }
    }

    int* output = new int[n];  
    int* count = new int[max + 1];

    for (int i = 0; i <= max; i++){        //initialize freq of all 0   count[] = {0, 0, 0, 0, 0, 0, 0, 0}
        count[i] = 0;
    }

    for (int i = 0; i < n; i++){           //calc freq of all     Count:     2 0 2 1 0 2 1
        count[p[i]]++;
    }

    for (int i = 1; i <= max; i++){        //to find which no ends at what index   Count:     2 2 4 5 5 7 8  ie 1 ends at 2, 2 ends at 2, 3 ends at 4, 4 ends at 5, 5 ends at 5, 6 ends at 7 and 7 ends at 8
        count[i] += count[i - 1];
    }

    for (int i = n - 1; i >= 0; i--){      //based on what ends where in backwards we fill the final answer ie output = {1, 1, 3, 3, 4, 6, 6, 7}
        output[count[p[i]] - 1] = p[i];
        count[p[i]]--;
    }

    for (int i = 0; i < n; i++){           //put the output back in the original array ie 'p'
        p[i] = output[i];
    }
    
}

void printArray(int*ar, int n){
    for(int i=0;i<n;i++){
        cout<<ar[i]<<" ";
    }
    cout<<endl;
}   

int main(){
    int p[8]={7,4,6,1,3,1,3,6};
    printArray(p,8);
    countSort(p,8);
    printArray(p,8);

    return 0;
}