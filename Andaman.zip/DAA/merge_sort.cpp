#include<iostream>
using namespace std;

int c = 0; // Global variable to count comparisons

// Function to print the elements of the array
void printArray(int Ar[], int size) {
    for (int i = 0; i < size; i++) {
        cout << Ar[i] << " ";
    }
    cout << endl;
}

// Function to merge two sorted subarrays into one sorted array
void merge(int* ar, int start, int mid, int end) {
    int leftSize = mid - start + 1;  // Size of left subarray
    int rightSize = end - mid;       // Size of right subarray

    // Create temporary arrays for left and right halves
    int* left = new int[leftSize];
    int* right = new int[rightSize];

    // Copy data into left and right arrays
    for (int i = 0; i < leftSize; i++) {
        left[i] = ar[start + i];
    }
    for (int i = 0; i < rightSize; i++) {
        right[i] = ar[mid + 1 + i];
    }

    // Merge the two arrays back into original array
    int i = 0, j = 0, k = start;
    while (i < leftSize && j < rightSize) {
        c++; // Count every comparison
        if (left[i] <= right[j]) {
            ar[k++] = left[i++];
        } else {
            ar[k++] = right[j++];
        }
    }

    // Copy any remaining elements from left array
    while (i < leftSize) {
        ar[k++] = left[i++];
    }

    // Copy any remaining elements from right array
    while (j < rightSize) {
        ar[k++] = right[j++];
    }

}

// Recursive Merge Sort function
void mergeSort(int* ar, int start, int end) {
    if (start < end) {
        int mid = (start + end) / 2;

        // Recursively sort left and right halves
        mergeSort(ar, start, mid);
        mergeSort(ar, mid + 1, end);

        // Merge sorted halves
        merge(ar, start, mid, end);
    }
}

int main() {
    int arr[] = {38,27,43,3,9,82,10}; // Input array
    int n = 7;

    // Sort the array using Merge Sort
    mergeSort(arr, 0, n - 1);

    // Print the sorted array
    cout << "Sorted array: ";
    printArray(arr, n);

    // Print the number of comparisons made
    cout << "Number of comparisons: " << c << endl;

    return 0;
}
