#include <iostream>     // For input/output
#include <climits>      // For INT_MAX constant
using namespace std;

#define V 5             // Number of vertices in the graph

// Function to find the vertex with the minimum key value not yet included in MST
int findMinKey(int key[], bool mstSet[]) {
    int min = INT_MAX;       // Initialize min value to inf
    int minIndex;            // Index of vertex with minimum key

    // Traverse all vertices to find the one with the smallest key not in MST
    for (int v = 0; v < V; v++)
        if (!mstSet[v] && key[v] < min) {           //not in MST and val is less than min
            min = key[v];                           //update min
            minIndex = v;    
        }

    return minIndex;         // Return index of vertex with min key
}

// Function to construct and print MST using Prim's algorithm
void primMST(int graph[V][V]) {
    int parent[V];   // Stores MST - parent[i] is parent of vertex i
    int key[V];      // Key values used to pick minimum weight edge
    bool mstSet[V];  // To represent the set of vertices included in MST

    // Initialize all keys to INF and mark all vertices as not yet in MST
    for (int i = 0; i < V; i++) {
        key[i] = INT_MAX;
        mstSet[i] = false;
    }

    key[0] = 0;        // Start from vertex 0, so key is 0
    parent[0] = -1;    // First node is root of MST, no parent

    // Build MST with V-1 edges
    for (int count = 0; count < V - 1; count++) {
        int u = findMinKey(key, mstSet);  // Pick the min key vertex not yet included
        mstSet[u] = true;                 // Add the picked vertex to MST

        // Update keys and parents of adjacent vertices of the picked vertex
        for (int v = 0; v < V; v++) {
            // graph[u][v] is non-zero means there is an edge
            // !mstSet[v] means vertex v is not yet in MST
            // graph[u][v] < key[v] means new weight is less, so update
            if (graph[u][v] && !mstSet[v] && graph[u][v] < key[v]) {
                parent[v] = u;            // Update parent
                key[v] = graph[u][v];     // Update key (edge weight)
            }
        }
    }

    // Print the MST using parent array
    cout << "Edge \tWeight\n";
    for (int i = 1; i < V; i++)
        cout << parent[i] << " - " << i << " \t" << graph[i][parent[i]] << "\n";         //graph[i][parent[i]] = weight of the edge
}

int main() {
    // Adjacency matrix of the graph
    int graph[V][V] = {
        {0, 2, 0, 6, 0},
        {2, 0, 3, 8, 5},
        {0, 3, 0, 0, 7},
        {6, 8, 0, 0, 9},
        {0, 5, 7, 9, 0}
    };

    primMST(graph);  // Call function to compute and print MST

    return 0;
}
