#include<iostream>
using namespace std;

int c=0; // Global counter for number of comparisons

// Function to maintain the Max-Heap property
void maxHeapify(int* ar, int n, int i){
    int max = i;              // Assume current index is the largest
    int left = i*2 + 1;       // Left child index
    int right = i*2 + 2;      // Right child index

    // Check if left child exists and is greater than root
    if(left < n && ar[left] > ar[max]){
        c++; // Count this comparison
        max = left;
    }
    // If left exists but not greater than current max (still counts as comparison)
    if(left < n && ar[left] < ar[max]){
        c++;
    }

    // Check if right child exists and is greater than current max
    if(right < n && ar[right] > ar[max]){
        c++; // Count this comparison
        max = right;
    }
    // If right exists but not greater than current max (still counts)
    if(right < n && ar[right] < ar[max]){
        c++;
    }

    // If the largest is not the root, swap and continue heapifying
    if(max != i){
        int temp = ar[i];
        ar[i] = ar[max];
        ar[max] = temp;

        // Recursively heapify the affected sub-tree
        maxHeapify(ar, n, max);
    }
}

// Function to build a Max-Heap from an unordered array
void buildMaxHeap(int* ar, int n){
    // Start from the last non-leaf node and heapify each one
    for(int i = n/2 - 1; i >= 0; i--){
        maxHeapify(ar, n, i);
    }
}

// HeapSort function
void heapSort(int* ar, int n){
    // Step 1: Build max heap
    buildMaxHeap(ar, n);

    // Step 2: Extract elements one by one from heap
    for (int i = n-1; i > 0; i--) {
        // Move current root to end
        int temp = ar[0];
        ar[0] = ar[i];
        ar[i] = temp;

        // Call maxHeapify on the reduced heap
        maxHeapify(ar, i, 0);
    }
}

// Utility function to print array
void printArray(int* ar, int n){
    for(int i = 0; i < n; i++){
        cout << ar[i] << " ";
    }
    cout << endl;
}

int main(){
    int p[6] = {2, 3, 1, 7, 6, 5}; // Sample array
    printArray(p, 6);             // Print original array

    heapSort(p, 6);               // Perform heapsort

    printArray(p, 6);             // Print sorted array
    cout << "number of comparisons " << c << endl; // Show total comparisons

    return 0;
}
