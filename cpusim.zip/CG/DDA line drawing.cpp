#include <iostream>
#include <graphics.h>
#include <cmath>
using namespace std;

void printCoord(int x, int y){
    cout<<"("<<x<<","<<y<<")";
}

int DDA(double x, double y, double xInc, double yInc, double steps){
    for(int i=1; i<=steps; i++){
        x += xInc;
        y += yInc;
        printCoord(round(x), round(y));
        line(round(x-xInc), round(y-yInc), round(x), round(y));
    }
}

int main(){
    double x1, y1, x2, y2;
    cout<<"Enter coordinates of starting point : ";
    cin>>x1>>y1;
    cout<<"Enter coordinates of ending point : ";
    cin>>x2>>y2;
    double dx = x2 - x1, dy = y2 - y1;
    double steps = (dx>=dy ? dx : dy);
    double xInc = dx/steps, yInc = dy/steps;
    int gd=DETECT, gm;
    initgraph(&gd, &gm, (char*)"");
    line(x1, y1, x2, y2);
    DDA(x1, y1, xInc, yInc, steps);
    getch();
    closegraph();
    return 0;
}

