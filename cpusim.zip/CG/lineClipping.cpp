#include <graphics.h>
#include <conio.h>
#include <math.h>

#define LEFT 1
#define RIGHT 2
#define BOTTOM 4
#define TOP 8

int outcode(int x, int y, int xmin, int ymin, int xmax, int ymax) {
    int code = 0;
    if (y > ymax) code |= TOP;
    if (y < ymin) code |= BOTTOM;
    if (x > xmax) code |= RIGHT;
    if (x < xmin) code |= LEFT;
    return code;
}

void cohen_sutherland(int x1, int y1, int x2, int y2, int xmin, int ymin, int xmax, int ymax) {
    int code1 = outcode(x1, y1, xmin, ymin, xmax, ymax);
    int code2 = outcode(x2, y2, xmin, ymin, xmax, ymax);
    int accept = 0;
    int code;
    while (true) {
        if ((code1 | code2) == 0) {
            accept = 1;
            break;
        } else if ((code1 & code2) != 0) {
            break;
        } else {
            int x, y;
            if (code1 != 0) {
                code = code1;
            } else {
                code = code2;
            }
            if (code & TOP) {
                y = ymax;
                x = x1 + (ymax - y1) * (x2 - x1) / (y2 - y1);
            } else if (code & BOTTOM) {
                y = ymin;
                x = x1 + (ymin - y1) * (x2 - x1) / (y2 - y1);
            } else if (code & RIGHT) {
                x = xmax;
                y = y1 + (xmax - x1) * (y2 - y1) / (x2 - x1);
            } else if (code & LEFT) {
                x = xmin;
                y = y1 + (xmin - x1) * (y2 - y1) / (x2 - x1);
            }
            if (code == code1) {
                x1 = x;
                y1 = y;
                code1 = outcode(x1, y1, xmin, ymin, xmax, ymax);
            } else {
                x2 = x;
                y2 = y;
                code2 = outcode(x2, y2, xmin, ymin, xmax, ymax);
            }
        }
    }
    if (accept) {
        line(x1, y1, x2, y2);
    }
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, (char*)"");

    int xmin = 100, ymin = 100, xmax = 300, ymax = 300;
    rectangle(xmin, ymin, xmax, ymax);

    int x1 = 150, y1 = 50, x2 = 250, y2 = 175;
    cohen_sutherland(x1, y1, x2, y2, xmin, ymin, xmax, ymax);

    getch();
    closegraph();
    return 0;
}