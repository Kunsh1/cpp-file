#include <cmath>
#include <iostream>
using namespace std;

class Matrix {
public:
  void Sum(int matrix1[3][3], int matrix2[3][3]) {

    cout << "Sum of Matrix1 and Matrix2:" << endl << endl;
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        cout << matrix1[i][j] + matrix2[i][j] << "  ";
      }
      cout << endl;
    }
    cout << endl;
    cout << endl;
  }

  void Transpose(int matrix1[3][3]) {

    cout << "Matrix1:" << endl << endl;
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        cout << matrix1[i][j] << " ";
      }
      cout << endl;
    }
    cout << endl;
    cout << endl;

    cout << "Transpose of matrix1:" << endl << endl;
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        cout << matrix1[j][i] << " ";
      }
      cout << endl;
    }

    cout << endl;
    cout << endl;
  }
  void Product(int matrix1[3][3], int matrix2[3][3]) {
    int matrix3[3][3] = {{0, 0, 0}, {0, 0, 0}, {0, 0, 0}};

    cout << "Product: " << endl << endl;
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        for (int k = 0; k < 3; k++) {
          matrix3[i][j] += matrix1[i][k] * matrix2[k][j];
        }
      }
    }
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        cout << matrix3[i][j] << "  ";
      }
      cout << endl;
    }
  }
};

int main() {
  Matrix matrixobj;
  int matrix1[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
  int matrix2[3][3] = {{7, 4, 2}, {3, 9, 11}, {6, 1, 3}};
  while (true) {
    int option;
    cout << endl
         << "1. Sum" << endl
         << "2. Transpose" << endl
         << "3. Multiply" << endl
         << "4. Exit" << endl
         << "Enter the option: ";
    cin >> option;
    cout << endl;
    cout << endl;
    if (option == 4) { return 0;}

      switch (option) {
      case 1: {
        matrixobj.Sum(matrix1, matrix2);
        break;
      }
      case 2: {
        matrixobj.Transpose(matrix1);
        break;
      }
      case 3: {
        matrixobj.Product(matrix1, matrix2);
        break;
      }
      }
  }
}