#include <cmath>
#include <iostream>
using namespace std;
class Triangle {
private:
  int side1, side2, side3;

public:
  Triangle(int s1, int s2, int s3) {
    if (s1 <= 0 || s2 <= 0 || s3 <= 0 || s1 + s2 <= s3 || s1 + s3 <= s2 ||
        s2 + s3 <= s1) {
      throw "Invalid Triangle sides";
    }
  }
  double perimeter(double s1, double s2, double s3) {
    return side1 + side2 + side3;
  }
  double area(double base, double height) { return 0.5 * base * height; }

  double area(double s1, double s2, double s3) {
    double s = (s1 + s2 + s3) / 2;
    double area = s * (s - s1) * (s - s2) * (s - s3);
    if (area > 0) {
      return sqrt(area);
    } else {
      return 0;
    }
  }
};
class triangle {};

int main() {
  try {
    Triangle t1(5, 12, 13);
    cout << "Perimeter of the right-angled triangle: "
         << t1.perimeter(5, 12, 13) << endl;

    Triangle t2(5, 12, 13);
    cout << "Area of the right-angled triangle: " << t2.area(12, 5) << endl;

    Triangle t3(12, 15, 20);
    cout << "Perimeter of the triangle: " << t3.perimeter(12, 15, 20) << endl;

    Triangle t4(12, 15, 20);
    cout << "Area of the triangle using Heron's formula: "
         << t4.area(12, 15, 20) << endl;

    Triangle t5(2, 0, 5);
  }

  catch (const char *msg) {
    cout << "Error: " << msg << endl;
  }

  return 0;
}