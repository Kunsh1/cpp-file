#include <iostream>
using namespace std;
int main() {
  char str1[100], str2[100], str3[100];
  ;
  cout << "Input str1: ";
  cin >> str1;
  cout << "Input str2: ";
  cin >> str2;
  // Length
  int str1length = 0;
  for (int i = 0; str1[i] != '\0'; i++) {
    str1length++;
  }
  int str2length = 0;
  for (int i = 0; str2[i] != '\0'; i++) {
    str2length++;
  }

  for (int i = 0; i < str1length; i++) {
    str3[i] = str1[i];
    str3[i + str1length] = str2[i];
    str3[str1length + str2length] = '\0';
  }
  int str3length = 0;
  for (int i = 0; str3[i] != '\0'; i++) {
    str3length++;
  }
  while (true) {
    int choice;
    cout << "1. Address" << endl;
    cout << "2. Concatenate" << endl;
    cout << "3. Compare" << endl;
    cout << "4. UPPER CASE" << endl;
    cout << "5. Reverse" << endl;
    cout << "6. Replace" << endl;
    cout << "7. Exit" << endl;
    cout << "Enter the option: ";
    cin >> choice;
    cout << endl;
    switch (choice) {
    case 1: {
      // Address
      for (int i = 0; i < str1length; i++) {
        cout << str1[i] << ": " << (void *)&str1[i] << endl;
      }
      for (int i = 0; i < str1length; i++) {
        cout << str2[i] << ": " << (void *)&str1[i] << endl;
      }
      cout<<endl<<endl;
      break;
    }
    case 2: {
      // concatination

      for (int i = 0; i < str3length; i++) {
        cout << str3[i];
      }

      cout << endl << endl;
      break;
    }
    case 3: {
      // Compare

      int result = 1;
      for (int i = 0; i < str1length; i++) {
        if (str1[i] != str2[i] || str1length != str2length) {
          result = 0;
          break;
        }
      }
      if (result == 1) {
        cout << "Strings are equal" << endl;
      } else {
        cout << "Strings are not equal" << endl;
      }
      cout << endl << endl;
      break;
    }

    case 4: {
      // Upper Case
      for (int i = 0; i < str3length; i++) {
        if (str3[i] >= 'a' and str3[i] <= 'z') {
          str3[i] = str3[i] - 32;
        }
        cout << str3[i];
      }
      cout << endl << endl;
      break;
    }
    case 5: {
      // Reverse
      for (int i = str3length - 1; i >= 0; i--) {
        cout << str3[i];
      }
      cout << endl << endl;
      break;
    }
    case 6: {
      // replace
      char str4[100];
      int str4length = 0;
      for (int i = 0; str4[i] != '\0'; i++) {
        str4length++;
      }

      cout << "Enter the string : ";
      cin >> str4;
      cout << "Enter Position: ";
      int Position;
      cin >> Position;
      if (str4length <= str3length) {
        for (int i = Position; i < str4length; i++) {
          str3[i] = str4[i - Position];
        }
      } else {
        cout << "Invalid Position: ";
      }
      for (int i = 0; i < str3length; i++) {
        cout << str3[i];
      }
      cout<<endl<<endl;
      break;
    }
    case 7: {
      return 0;
    }
    }
  }
}