#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
using namespace std;

int main() {
  ifstream inputFile("file1.txt");
  ofstream outputFile("file2.txt");

  if (!inputFile) {
    cerr << "Error: Unable to open input file." << endl;
    return 1;
  }

  if (!outputFile) {
    cerr << "Error: Unable to open output file." << endl;
    return 1;
  }

  stringstream buffer;
  buffer << inputFile.rdbuf();
  string content = buffer.str();
  string modifiedContent;
  string result;
  for (char c : content) {
    if (!isspace(c)) {
      result += c;
    }
  }
  modifiedContent = result;

  outputFile << modifiedContent;

  cout << "Whitespaces removed and content copied successfully!" << endl;

  inputFile.close();
  outputFile.close();

  return 0;
}