
#include <cmath>
#include <iostream>
using namespace std;

int main() {
    // Enter Array
    int n = 0;
    cout << "Enter the number of elements: ";
    cin >> n;
    int arr_main[n];
    for (int i = 0; i < n; i++) {
      cout << "Enter the value of arr[" << i << "]: ";
      cin >> arr_main[i];
    }
    cout << endl;

    cout << "Your Input: ";
    for (int i = 0; i < n; i++) {
      cout << arr_main[i] << " ";
    }
    cout << endl;
    cout << endl;

      // Remove duplicates
      for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
          if (arr_main[i] == arr_main[j]) {
            for (int k = j; k < n; k++) {
              arr_main[k] = arr_main[k + 1];
            }
            n--;
          }
        }
      }

      cout << "Your Output: ";
      for (int i = 0; i < n; i++) {
        cout << arr_main[i] << " ";
      }
      cout << endl;
      cout << endl;


  }