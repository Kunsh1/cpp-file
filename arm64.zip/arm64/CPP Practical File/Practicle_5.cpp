#include <iostream>
using namespace std;

int main() {
  int arr1[5]={1,3,5,7,9,},arr2[5]={2,4,6,8,10};
    int n=10;
    int arr_main[10], arr_temp[n];
    for (int i = 0; i < 5; i++){
        arr_main[i] = arr1[i];
        arr_main[i+5]=arr2[i];
    }
    n=sizeof(arr_main)/sizeof(arr_main[0]);

    int min_index = 0;
    for (int i = 0; i < n; i++) {
        int min = arr_main[i];
        min_index = i;
        for (int j = i + 1; j < n; j++) {
            if (arr_main[j] < min) {
                min = arr_main[j];
                min_index = j;
            }
        }
        arr_temp[i] = min;
        arr_main[min_index] = arr_main[i];
    }

    cout << "Sorted Array: ";
    for (int i = 0; i < n; i++) {
        cout << arr_temp[i] << " ";
    }

    return 0;
}