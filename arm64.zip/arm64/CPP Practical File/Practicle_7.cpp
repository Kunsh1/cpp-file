#include <cmath>
#include <iostream>
using namespace std;

int main() {
  int a=36,b=60;
  for (int i=a; i>1; i--){
    if (a%i==0){
        if (b%i==0){
          cout<<i<<endl;
          break;
          }
        }

    }
  }