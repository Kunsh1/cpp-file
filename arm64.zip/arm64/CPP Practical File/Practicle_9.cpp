#include <iostream>
using namespace std;

class person{
public:
string name1;
person(string name2){
  name1=name2;
}
void display(){
  cout<<name1<<endl;

}
};
class student:public person {
  public:
string course1;
int marks1,year1;
student(string name2,string course2,int marks2,int year2):person(name2){
  course1=course2;
  marks1=marks2;
}
void display(){
  person::display();
  cout<<course1<<endl;
  cout<<marks1<<endl;
  cout<<year1<<endl;
}
};
class Employee:public person{
public:
string department1;
int salary1;
Employee(string name2,string department2,int salary2):person(name2){
  department1=department2;
  salary1=salary2;
}
void display(){
  person::display();
  cout<<department1<<endl;
  cout<<salary1<<endl;
}
}
;

int main() {
  person* personPtr;
  student student("Deepali", "Computer Science", 85, 2023);
  Employee employee("Pranay", "Human Resources", 50000);

  // Using runtime polymorphism
  personPtr = &student;
  personPtr->display();

  personPtr = &employee;
  personPtr->display();

}