#include <iostream>
#include <cmath>
using namespace std;

int main() {
    int n;
    double sum = 0.0;
    cout << "Enter the number of terms: ";
    cin >> n;
    for (int i = 1; i <= n; ++i) {
        if (i % 2 == 0)
            sum -= 1/pow(i,i); // subtracting even terms
        else
            sum += 1/pow(i,i); // adding odd terms
        // sum += 1.0/i;
    }
    cout << "Sum of series: " << sum;
    return 0;
}