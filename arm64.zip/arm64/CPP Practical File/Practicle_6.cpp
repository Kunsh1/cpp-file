#include <iostream>
using namespace std;

int main() {
  int arr1[]={1,2,3,4,5,6};
 int n=sizeof(arr1)/sizeof(arr1[0]);
    int a=4;
    for(int i=0;i<n;i++){
        if(a==arr1[i]){
            cout<<"Element is present in the array at index "<<i;
           break;
        }
    }

}