#include <stdio.h>
#include <stdlib.h>

int main() {
    int result2 = system("cat /proc/version");
    int result1 = system("cat /proc/cpuinfo | grep 'cpu ' ");

    return 0;
}