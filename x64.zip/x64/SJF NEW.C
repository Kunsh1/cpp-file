#include<stdio.h>

int main() {
    int n;
    printf("Number of processes ");
    scanf("%d", &n);

    int burst[n];
    for(int i = 0; i < n; i++) {
        printf("\nEnter Process Burst Timefor P[%d]\n ", i+1);
        scanf("%d", &burst[i]);
    }

    for(int i = 0; i < n-1; i++) {
        for(int j = i+1; j < n; j++) {
            if(burst[i] > burst[j]) {
                int temp = burst[i];
                burst[i] = burst[j];
                burst[j] = temp;
                }
        }
    }
    for(int i = 0; i < n; i++) {
        printf("sorted burst time for P[%d]:", i+1);
        printf("%d\n ", burst[i]);
    }
    printf("\n");

    int waiting[n], turnaround[n];
     waiting[0] = 0;
    for(int i = 1; i < n; i++) {
        waiting[i] = waiting[i-1] + burst[i-1];
    }

    for(int i = 0; i < n; i++) {
        printf("Waiting time for P[%d]:", i+1);
        printf("%d\n", waiting[i]);
    }

    for(int i = 0; i < n; i++) {
        turnaround[i] = burst[i] + waiting[i];
    }

    for(int i = 0; i < n; i++) {
        printf("Turnaround time for P[%d]:", i+1);
        printf("%d\n", turnaround[i]);
    } 
   

    return 0;
}
// 5 6 4 2 1