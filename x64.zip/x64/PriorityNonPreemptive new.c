#include<stdio.h>

int main() {
    int n;

    printf("Number of processes: ");
    scanf("%d", &n);

    int burst[n], waiting[n], turnaround[n], priority[n], arrivalTime[n], index[n];

    for(int i = 0; i < n; i++) {
        printf("\nEnter Process Burst Time for P[%d]: ", i+1);
        scanf("%d", &burst[i]);
        index[i] = i;
    }

    for(int i = 0; i < n; i++) {
        printf("\nEnter Priority for P[%d]: ", i+1);
        scanf("%d", &priority[i]);
    }

    for(int i = 0; i < n; i++) {
        printf("\nEnter Arrival Time for P[%d]: ", i+1);
        scanf("%d", &arrivalTime[i]);
    }

    for(int i = 0; i < n - 1; i++) {
        for(int j = i + 1; j < n; j++) {
            if(priority[i] > priority[j]) {
                int temp = priority[i];
                priority[i] = priority[j];
                priority[j] = temp;

                temp = index[i];
                index[i] = index[j];
                index[j] = temp;
            }
        }
    }

    int sortedBurst[n], sortedArrival[n];
    for(int i = 0; i < n; i++) {
        sortedBurst[i] = burst[index[i]];
        sortedArrival[i] = arrivalTime[index[i]];
    }

    waiting[0] = 0;
    for(int i = 1; i < n; i++) {
        waiting[i] = waiting[i-1] + sortedBurst[i-1];
    }

    for(int i = 0; i < n; i++) {
        turnaround[i] = sortedBurst[i] + waiting[i];
    }

    for(int i = 0; i < n; i++) {
        printf("\nProcess P[%d]:", index[i] + 1);
        printf("\nBurst Time: %d", sortedBurst[i]);
        printf("\nPriority: %d", priority[i]);
        printf("\nArrival Time: %d", sortedArrival[i]);
        printf("\nWaiting Time: %d", waiting[i]);
        printf("\nTurnaround Time: %d\n", turnaround[i]);
    }

    return 0;
}
