#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>  // Include this for atoi

int sum;
void *runner(void *param);

int main(int argc, char *argv[]) {
    pthread_t tid;
    pthread_attr_t attr;

    if (argc != 2) {
        fprintf(stderr, "usage: %s <non-negative integer>\n", argv[0]);
        return -1;
    }

    int input_value = atoi(argv[1]);  // atoi converts the argument to an integer
    if (input_value < 0) {
        fprintf(stderr, "Error: The integer value must be non-negative.\n");
        return -1;
    }

    pthread_attr_init(&attr);
    pthread_create(&tid, &attr, runner, (void *)(size_t)input_value);  // Pass the integer directly
    pthread_join(tid, NULL);

    printf("sum = %d\n", sum);

    return 0;
}

void *runner(void *param) {
    int upper = (int)(size_t)param;
    sum = 0;
    for (int i = 1; i <= upper; i++) {
        sum += i;
    }
    pthread_exit(0);
}
