#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    pid_t pid = fork(); 

    if (pid < 0) {

        printf("Problem in fork");
    } else if (pid == 0) {

        printf("Same program, same code\n");
    } else {;
        printf("Same program, same code\n");
    }

    return 0;
}

