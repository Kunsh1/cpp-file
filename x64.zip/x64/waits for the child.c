#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>

int main() {
  pid_t pid;
  pid = fork();
  if (pid < 0) {
    printf("Problem in fork");
  } else if (pid == 0) {
    printf("Inside the child process");
  } else {
    wait(NULL);
  }
  printf("\nParent\n");
}
