#include <stdio.h>

int main() {
    int p, m;

    printf("Enter number of processes: ");
    scanf("%d", &p);
    printf("Enter number of memory blocks: ");
    scanf("%d", &m);

    int processSizes[p], memorySizes[m];

    for (int i = 0; i < p; i++) {
        printf("Enter size of process %d: ", i + 1);
        scanf("%d", &processSizes[i]);
    }

    for (int i = 0; i < m; i++) {
        printf("Enter size of memory block %d: ", i + 1);
        scanf("%d", &memorySizes[i]);
    }

    for (int i = 0; i < p; i++) {
        int allocated = 0;

        for (int j = 0; j < m; j++) {
            if (memorySizes[j] >= processSizes[i]) {
                memorySizes[j] -= processSizes[i];
                printf("Allocating process %d to memory block %d\n", i + 1, j + 1);
                printf("Size remaining in memory block %d: %d\n\n", j + 1, memorySizes[j]);
                allocated = 1;
                break;
            }
        }

        if (!allocated) {
            printf("Not enough memory for process %d\n", i + 1);
        }
    }

    return 0;
}
