#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    pid_t pid = fork();

    if (pid < 0) {
         printf("Problem in fork");
    } else if (pid == 0) {
        printf("Same program, different code\n");
        printf("Child executing different code...\n");
    } else {
        printf("Parent Process");
    }

    return 0;
}

