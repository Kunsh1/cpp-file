#include<stdio.h>
#define nl printf("\n")
#define max 10
#define Q 2
typedef struct
{
	int id;
	int btm;
	int atm;
} process;

int main()
{
	process tmp,p[max];
	int n,i,j,tbt,t,atm,btm,q;
	q=Q;
	printf("Enter no. of processes : ");	scanf("%d",&n);
	nl;

	i=0,tbt=0;
	while(i<n)
	{
		nl;
		printf("For process %d",i+1);
		nl;
		printf("Enter arrival time : ");	scanf("%d",&atm);
		nl;
		printf("Enter burst time : ");		scanf("%d",&btm);
		
		tbt+=btm;

		p[i].id=i+1;
		p[i].btm=btm;
		p[i].atm=atm;
		
		i++;		
	}

        
	i=0,j=i+1;
	while(i<n)
	{
		while(j<n)
		{
			if(p[i].atm > p[j].atm)
			{
				tmp=p[i];
				p[i]=p[j];
				p[j]=tmp;
			}
			j++;
		}
		i++;
		j=i+1;
	}

	printf("\nTime\t\tProcess");
	nl;
	t=btm=0;
	
	while(t<tbt)
	{	
		if(q!=0 && p[btm].btm!=0)
		{
			printf("%d\t\t\t%d",t+1,p[btm].id);	p[btm].btm--;	q--;	t++;
			nl;
		}
		else
		{
			q=Q;

			if(btm==(n-1))
			btm=0;
			else
			btm++;
		}
		
	}
	return 0;
}
