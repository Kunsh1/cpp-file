#include <stdio.h>
#include <stdlib.h>

int main() {

    printf("Memory information:\ntotal: ");
    system("cat /proc/meminfo | awk 'NR==1{print}'");
    printf("\nused : ");
    system("cat /proc/meminfo | awk 'NR==2{print}'");
    printf("\nfree : ");
    system("cat /proc/meminfo | awk 'NR==1 {a=$2} NR==2 {b=$2} END {print a-b}'");

    return 0;
}
