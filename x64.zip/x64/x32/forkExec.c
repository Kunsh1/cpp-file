#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid; // Process ID for the child process

    // Fork a new process
    pid = fork();

    if (pid < 0) {
        // Error occurred during fork
        perror("Fork failed");
        exit(1);
    } else if (pid == 0) {
        // Child process
        printf("Child Process: PID = %d, PPID = %d\n", getpid(), getppid());

        // Case (i): Same program, same code
        printf("Case (i): Same program, same code\n");
        // Child simply continues executing the same code as the parent.

        // Case (ii): Same program, different code
        printf("Case (ii): Same program, different code\n");
        printf("Child executing different code...\n");
        exit(0); // Exit after completing the child's task
    } else {
        // Parent process
        printf("Parent Process: PID = %d, Child PID = %d\n", getpid(), pid);

        // Case (iii): Parent waits for the child to finish
        printf("Parent waiting for child to complete...\n");
        wait(NULL); // Wait for the child process to terminate
        printf("Child process completed. Parent resumes.\n");
    }

    return 0;
}
