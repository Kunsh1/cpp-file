#include <stdio.h>

typedef struct
{
    int id;
    int burstTime;
    int waitingTime;
    int turnAroundTime;
} process;

int main()
{
    process p[20];
    int n, i, j;
    int totalWaitingTime = 0, totalTurnAroundTime = 0;

    printf("Enter total number of processes (maximum 20): ");
    scanf("%d", &n);

    printf("\nEnter Process Burst Time\n");
    for (i = 0; i < n; i++)
    {
        printf("P[%d]: ", i + 1);
        scanf("%d", &p[i].burstTime);
        p[i].id = i + 1;
    }

    for (i = 0; i < n - 1; i++)
    {
        for (j = i + 1; j < n; j++)
        {
            if (p[i].burstTime > p[j].burstTime)
            {
                process temp = p[i];
                p[i] = p[j];
                p[j] = temp;
            }
        }
    }

    p[0].waitingTime = 0;
    for (i = 1; i < n; i++)
    {
        p[i].waitingTime = p[i - 1].waitingTime + p[i - 1].burstTime;
    }

    for (i = 0; i < n; i++)
    {
        p[i].turnAroundTime = p[i].waitingTime + p[i].burstTime;
        totalWaitingTime += p[i].waitingTime;
        totalTurnAroundTime += p[i].turnAroundTime;
    }

    printf("\nProcess\t\tBurst Time\tWaiting Time\tTurnaround Time\n");
    for (i = 0; i < n; i++)
    {
        printf("P[%d]\t\t%d\t\t%d\t\t%d\n", p[i].id, p[i].burstTime, p[i].waitingTime, p[i].turnAroundTime);
    }

    printf("\nAverage Waiting Time: %.2f", (float)totalWaitingTime / n);
    printf("\nAverage Turnaround Time: %.2f", (float)totalTurnAroundTime / n);

    return 0;
}
