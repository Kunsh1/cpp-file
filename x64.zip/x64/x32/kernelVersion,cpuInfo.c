#include <stdio.h>
#include <stdlib.h>

int main() {

    printf("Kernel version: ");
    system("cat /proc/version");
    printf("\n");

    printf("CPU information:\n");
    system("cat /proc/cpuinfo | awk 'NR==3 || NR==4 || NR==5 {print}'");
    printf("\n");

    return 0;
}
